# CodeCraft incremental Code-First workflow 1.7.11

Read entry.json. IN/OUT semantic validation and patch integration policies match package0 workflow1.3.0. Under package0 use its root policy and review locations. Standalone use Design.policy_binding paths. Reuse/fallback and provenance rules remain artifact-based; a valid UNVERIFIED handoff is not runtime verification. ZIP-only exchange needs no AEP.

## Target HAL integration
Explicit Integrate board directives use the supplied HAL profile artifact. Follow Design.board_integration_policy; unknown hardware mapping is a finding, never invented wiring. Existing hardware evidence is not validation for a new board.

## HAL board integration
Bounded two-column DDR/END_DDR tables, partial/rename-only profiles, Resources and behavioral platform activation are declared in Deployment.board_integration_policy. Preserve immutable pair and supplied active resource patches; board change is not patch integration.

## Current acceptance and integrated patch history
A generation report records generation-time state and must be labelled historical when current Runtime.validation supersedes it. Link current acceptance and scoped evidence. After exact patch integration, current handoff/output/pair dispositions agree: integrated scope has no active replacements; original patch sources, manifests and evidence remain historical unchanged inputs. Unselected scopes remain active. OUT reviews check this consistency.

## Typed HAL scalar transfer
Two columns remain. Use JSON scalar literals: quoted text, unprefixed numbers and true/false booleans. Input accepts uppercase booleans too. Export canonicalizes lowercase booleans and quoted strings/board names. Unquoted DELETE is a Resource removal operation; quoted "DELETE" is text. Blank is unspecified; quoted empty text is explicit. Editor/import/export enforce declared row types. package0 carries native JSON scalars and value_types, with separate deletions; never infer scalar type again from text. Hardware, GPIO range/integer rules and required-property/dependency checks remain Model-First review.

## PinMap cleanup and board notes
Unquoted DELETE explicitly removes a PinMap key or Resource property only from the target projection. Quoted "DELETE" remains literal text. Record the deletion separately from blanks, -1 and unresolved rows. Check dependencies and report a finding if a required binding would be broken; never modify the supplied pair or Default.

Optional Notes: immediately after DDR is JSON-quoted board documentation (escaped newlines allowed), not a HAL path or executable requirement. Preserve it in handoff context without deriving hardware behavior from it. A notes-only block adds no wiring instructions.

## Browsed deployment zero patch ZIPs

A USER_BROWSED_ZIP patch may be manually assembled with no entry.json. Only indexed device/ payload files are proposed targets. Keep the original ZIP as immutable provenance; extra original ZIP members are inert unless separately declared. Verify the original and indexed replacement hashes and compare the recorded observed preimage to the selected pair. An observed hash is not proof of compatibility or owner acceptance.

For authorized integration, the Model-First assistant compares affected C# method signatures and contract-facing behavior against the selected pair and affected DDR contracts, including parameter and return types, visibility, interface/override relationships and callers. Assess new files, references and non-C# dependencies as applicable; record exact findings, paths and hashes. The Code-First worker independently validates this review and the delivered contracts before generating.

When authorized for integration, reconcile a signature or other contract change in the new Model-First projection and its dependency closure before Code-First. For placement-only scope follow Design.patch_integration_policy.include_only; never silently change DDR, patch bytes or the immutable pair.

REVIEW_REQUIRED means the importer has packaged a candidate, not validated placement. Do not infer VERIFIED from a ZIP import, signature match or integration.

## Include only

Files marked application_stage=VS2022_POST_PLACEMENT_ONLY are manual VS2022 replacement inputs. Carry their exact bytes, manifest, hashes and provenance into the Code-First handoff without applying them to the generation workspace or including them in generated package2 device/ sources. Their signature/preimage mismatch or pending review must not block, change or force fallback for Model-First or Code-First generation. Review compatibility against the actual Code-First target before manual replacement in VS2022; block only the incompatible replacement. This rule does not waive package integrity checks or change inherited active baseline overlays. An explicit matching Integrate patch directive instead routes the selected scope and its dependency closure through Model-First and Code-First.

## Output naming and review corrections

New outputs use the Explorer-selected ModelCraft_ prefix; legacy CodeCraft_ inputs remain valid and immutable. Use the projection family, target version and output names from package0. Review corrections preserve the user-selected version and canonical filenames. A new target version requires a new user request. Record the prior and replacement SHA-256 and the correction reason. Retain the exact superseded archive at a content-addressed history path, preserving original review bytes; map the historical subject to its stored path. Bind the new OUT review to the replacement SHA-256. Only the candidate referenced by the active handoff may proceed.

## Step 2 result README

After Step 2, replace the pending placeholder in package2/README.md. For each result, report its exact archive path, state and verification scope from the final manifest. Distinguish inherited evidence from newly performed checks. Refresh the README after verification or any state change; validate that it agrees with the final manifest before handoff.
