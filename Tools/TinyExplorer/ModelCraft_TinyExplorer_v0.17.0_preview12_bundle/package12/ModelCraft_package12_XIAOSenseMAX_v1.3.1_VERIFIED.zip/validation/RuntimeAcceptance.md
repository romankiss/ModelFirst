# XIAOSenseMAX v1.3.1 runtime acceptance

Operator-reported compile and flash: OK. AppLog confirms the package2
XIAOSenseMAX 1.3.1 banner at 14:57:12.003 and six workers (SYS, EMPTY0,
EMPTY1, MEDIA, SENSORS, LORA). NEO, LED and BUTTON were unassigned and
skipped. SYS FLASH OPEN, LORA OPEN and LORA SETUP returned +OK.
Modules reached READY and ApplicationStartUp Done at 14:57:22.542.

| Check | RKB evidence |
| --- | --- |
| INFO | 00003101 returns DATA with name=Empty_EMPTY0, atGroup=EMPTY0, enabled=True, rxCount=1. |
| LOOPBACK | 00003102 internal ECHO returns LOOPBACK_TEST; LOOPBACK returns DATA OK with the same context. |
| Tagged PUSH | 00003103 adds the ECHO_LOG subscription. 00003104 TAG test reaches EMPTY0 handler with the tag in the filter. 00003105 miss returns DATA without event delivery. 00003106 removes one route. |
| SEND_ACK | 00003110 reuses the EMPTY0 PUSH route and enqueues PING #3110. QueueTX at 15:02:14.617, RX from 0x5557 to 0x0888 at 15:02:20.271 and EMPTY0 handler at 15:02:20.338 share ctx=00003110. Handler payload is ACK_PING #3110. |
| Additional ACK | 0x5000 to 0x0888 at 15:02:23.143, delivered to EMPTY0 with ACK_PING #3110 and ctx=00000000. |

Acceptance scope: build, flash, startup and targeted EMPTY0/LORA smoke
tests on XIAO ESP32S3 Sense. MEDIA and SENSORS worker startup was observed.
Peripheral operation regression was outside the scope of this run.
