# Empty0 v1.3.1 runtime acceptance

Operator-reported compile and flash: OK. Visual Studio confirms banner
`ModelCraft_package2_Empty0 1.3.1`; AppLog confirms the EMPTY0 worker start
and `EMPTY0 READY` at 14:37:49.567.

| Check | RKB evidence |
| --- | --- |
| ECHO / LOOPBACK | 00001202 empty DATA, 00001203 DATA a,b, 00001204 internal ECHO shares the context and LOOPBACK returns DATA OK. |
| Routing | 0000120B ENOHANDLER for UNKNOWN, 0000120C publish_nomatch for EMPTY1. |
| Invalid arguments | 0000120D INFO and 0000120E LOOPBACK return EARGS; no internal ECHO is logged for the rejected LOOPBACK. |
| Filtered PUSH | 00001206 SUBLIST count=1. 00001207 probe reaches handler_event. 00001208 miss returns DATA with no delivery trace. 00001209 removes one route; 0000120A count=0. |
| Tagged PUSH | 00190004 reaches handler_event with TAG test and $tag=ECHO_LOG. 00190005 miss returns DATA with no delivery trace. 00190006 removes one route. |
| Trace truncation | 00001221 handler_event logs [TRUNCATED at 128]; ECHO returns the full 129 ASCII characters. |
| Async ECHO | 00001222 enqueue, execute, event delivery, handler and DATA async-probe share the same context. Wildcard route removed at 00001223. |
| Restart and INFO | 14:48:01.785 EMPTY0 READY. 00001230 returns +DATA:00001230,EMPTY0:name=Empty_EMPTY0,atGroup=EMPTY0,enabled=True,rxCount=1. |

Acceptance scope: MIN startup and the recorded EMPTY0 regression. Extended
Level 0 cases (empty filter, duplicate SUB update, TOGGLE, SWITCH and PULL)
and independent capture of the full event payload at the event sink were
outside this run. The tag test covers delivery with the tag preserved in the
filter. The application dispatcher example is commented.

The promoted pair preserves all tested firmware/build inputs and DDR bytes.
