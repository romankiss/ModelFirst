# ModelCraft package0 workflow 1.3.17

Package = State = Context. Start with root entry.json, package0/entry.json and declared human task. ZIP IN → ZIP OUT is a complete supported workflow; AEP is optional.

## Notepad sections

Notepad supports free prose without section markers. Optional Lxx IDs (for example L01) identify requirements; use an ID on its own line or the existing Lxx. text form. Recognized directive headers are Deploy module:, Integrate board:, Integrate patch:, Integrate nuget: and Integrate module:. A blank line closes an open structured section; the next nonempty block must start with a recognized directive or Lxx ID. A recognized header also ends the preceding details without a blank line. Free prose before the first structured section is allowed. Integrate board: inline permits blank lines before DDR and within DDR / END_DDR tables; consecutive tables for the same board are allowed. Report orphan blocks against the first nonempty source line and resolve before generation.

## Module and sensor shortcuts

These commands are optional shortcuts for an increment against a trained baseline pair. A request may also use free prose or add details to a shortcut.

- `Integrate module: MODULE:BASE` — Create a new Module Contract based on an existing BASE Module Contract in the selected pair.
- `Integrate module: MODULE-SENSOR` — Remove only the named existing sensor from MODULE. Remove or reconcile affected dependencies with the human requirements; never infer removal of MODULE or unrelated sensors.
- `Integrate module: MODULE+SENSOR.HANDLER` — Add the named handler to the named existing sensor in the existing module, preserving other handlers.
- `Integrate nuget: MODULE:BASE+SENSOR.HANDLER[.HANDLER...]+PACKAGE_ID` — Create MODULE from the existing BASE only if MODULE is absent. Add the named sensor and implement only the requested handlers backed by the selected NuGet assembly API.
- `Integrate nuget: MODULE+SENSOR.HANDLER[.HANDLER...]+PACKAGE_ID` — Add the named sensor and requested API-backed handlers to an existing MODULE. Do not infer a base for an absent module.

Resolve module, sensor and handler identities and actual package ID/API before changing Model-First. Do not silently overwrite an existing sensor or handler, invent API support, or remove unrelated contracts.

## Roles and authority
The human task defines requested change. The selected immutable package12 defines baseline interfaces/implementation and actual acceptance scope. Root entry.json defines phases, IN/OUT validation, patch integration, scope and permitted writes. package0/contracts/ supplies the referenced versioned schemas and mechanics, never extra application requirements. The declared downstream workflow v1.7.9 owns artifact-level reuse and Code-First validation under the same root rules.

1. MODEL_FIRST_ASSISTANT validates IN, creates complete package1, reviews semantics and OUT, returns separate package1 and handoff downloads, then STOP.
2. Only a new explicit instruction authorizes CODE_FIRST_WORKER. Independently review package1 IN, implement demonstrated impact and byte-reuse unaffected artifacts, review OUT, return complete UNVERIFIED package2 and handoff, then STOP.
3. Tester supplies compile/flash/runtime evidence. Verification assesses the declared profile and exact bytes. Neither generated code nor a passed document review is VERIFIED.

Missing authoritative inputs or unresolved semantic contradictions block affected work. Prior MODEL_FIRST_READY is not a substitute for independent semantic review. A corrected input requires a new Model-First output, not a silent Code-First repair. Preserve immutable inputs, task text, fingerprints and explicit manifest history. Reports bind exact subject hashes under package0/reviews/; Runtime.reviews indexes them. Initial package0 review binds its retained pre-index manifest snapshot to avoid self-hash recursion.

## Increment and overlays
A complete output is not authorization to regenerate everything. Derive changes and dependency closure from actual requirements and baseline. Reuse unaffected bytes; local impact, redundant metadata or overlay presence alone do not justify full fallback/regression. Root/downstream policy defines evidence-backed fallback.

Default: preserve all active deployment_zero_patch context, including contract/evidence/replacements. Integrate only via the declared current human directive. Ambiguous/conflicting selection records a finding and preserves affected patch scope. Integrity or unsafe placement still blocks. Model-First → Code-First integration retires only successfully reconciled active scope, retaining history. Integration does not grant VERIFIED.

## Task files, tests and references
Only included declared task artifacts define application behavior. Empty/excluded/NONE diagram adds no diagram requirement. Tutorial snippets and schema examples are teaching only. Pair member paths resolve inside the named baseline ZIP; current task paths resolve from this ZIP root. Origin references resolve under their declared resolution_root. Historical external references are provenance, not active missing inputs.

Current acceptance follows task, relevant contracts and demonstrated impact. Baseline tests/logs/reports describe their original state, not new tests to run. Retire superseded active test indexes in new outputs and preserve historical evidence. Do not invent ###, branching or test Role semantics: executable tests require a supplied compatible Role; otherwise provide a plan and mark execution unavailable.

Output naming comes from task projections. Return byte-identical standalone and nested result ZIPs with actual SHA-256; preserve source package0/core lineage. Never recursively embed whole previous transaction bundles. Record limitations and keep UNVERIFIED when required runtime evidence is missing.

## Target HAL integration
Explicit Integrate board directives use the supplied HAL profile artifact. Follow Design.board_integration_policy; unknown hardware mapping is a finding, never invented wiring. Existing hardware evidence is not validation for a new board.

## HAL board integration
Bounded two-column DDR/END_DDR tables, partial/rename-only profiles, Resources and behavioral platform activation are declared in Design.board_integration_policy. Preserve immutable pair and supplied active resource patches; board change is not patch integration.

## Current acceptance and integrated patch history
A generation report records generation-time state and must be labelled historical when current Runtime.validation supersedes it. Link current acceptance and scoped evidence. After exact patch integration, current handoff/output/pair dispositions agree: integrated scope has no active replacements; original patch sources, manifests and evidence remain historical unchanged inputs. Unselected scopes remain active. OUT reviews check this consistency.

## Typed HAL scalar transfer
Two columns remain. Use JSON scalar literals: quoted text, unprefixed numbers and true/false booleans. Input accepts uppercase booleans too. Export canonicalizes lowercase booleans and quoted strings/board names. Unquoted DELETE is a Resource removal operation; quoted "DELETE" is text. Blank is unspecified; quoted empty text is explicit. Editor/import/export enforce declared row types. package0 carries native JSON scalars and value_types, with separate deletions; never infer scalar type again from text. Hardware, GPIO range/integer rules and required-property/dependency checks remain Model-First review.

## PinMap cleanup and board notes
Unquoted DELETE explicitly removes a PinMap key or Resource property only from the target projection. Quoted "DELETE" remains literal text. Record the deletion separately from blanks, -1 and unresolved rows. Check dependencies and report a finding if a required binding would be broken; never modify the supplied pair or Default.

Optional Notes: immediately after DDR is JSON-quoted board documentation (escaped newlines allowed), not a HAL path or executable requirement. Preserve it in handoff context without deriving hardware behavior from it. A notes-only block adds no wiring instructions.

## Browsed deployment zero patch ZIPs

A USER_BROWSED_ZIP patch may be manually assembled with no entry.json. Only indexed device/ payload files are proposed targets. Keep the original ZIP as immutable provenance; extra original ZIP members are inert unless separately declared. Verify the original and indexed replacement hashes and compare the recorded observed preimage to the selected pair. An observed hash is not proof of compatibility or owner acceptance.

For authorized integration, the Model-First assistant compares affected C# method signatures and contract-facing behavior against the selected pair and affected DDR contracts, including parameter and return types, visibility, interface/override relationships and callers. Assess new files, references and non-C# dependencies as applicable; record exact findings, paths and hashes. The Code-First worker independently validates this review and the delivered contracts before generating.

When authorized for integration, reconcile a signature or other contract change in the new Model-First projection and its dependency closure before Code-First. For placement-only scope follow Design.patch_integration_policy.include_only; never silently change DDR, patch bytes or the immutable pair.

REVIEW_REQUIRED means the importer has packaged a candidate, not validated placement. Do not infer VERIFIED from a ZIP import, signature match or integration.

## Include only

Files marked application_stage=VS2022_POST_PLACEMENT_ONLY are manual VS2022 replacement inputs. Carry their exact bytes, manifest, hashes and provenance into the Code-First handoff without applying them to the generation workspace or including them in generated package2 device/ sources. Their signature/preimage mismatch or pending review must not block, change or force fallback for Model-First or Code-First generation. Review compatibility against the actual Code-First target before manual replacement in VS2022; block only the incompatible replacement. This rule does not waive package integrity checks or change inherited active baseline overlays. An explicit matching Integrate patch directive instead routes the selected scope and its dependency closure through Model-First and Code-First.

## Deployment zero patch request

Only DEPLOYMENT_ZERO_PATCH_REQUESTED / DEPLOYMENT_ZERO_PATCH_WORKER authorizes this reverse path. Read package0/Notepad.txt, Design.deployment_zero_patch_request and the exact embedded VERIFIED Package 12. Verify the pair and both member hashes. For legacy requests with a target path and target hash, verify and honor both.

Resolve the minimal set of existing Code-First files from the human change described in Notepad, using source, module metadata and DDR in the verified pair. A line such as Deploy module: CAM scopes the request to the existing CAM module. Multiple Deploy module: lines may name different modules; apply the described changes to the relevant files only. The directive scopes the patch. Any existing module may be copied without a change description. No directive authorizes deployment. If intent, module identity or target files cannot be resolved, request clarification. Preserve all signatures, public commands, parameters, responses, events and declared behavior; any change to these belongs in a normal increment. Do not add files or dependencies. Do not replace a target with an unresolved active overlay in the pair.

- Program.cs: Deploy module: Program.cs selects exactly device/Program.cs in the Code-First pair. Require a description in that section. Apply only the described implementation changes; preserve signatures, contracts and board/PinMap declarations.
- packages.config: Deploy module: packages.config selects exactly device/packages.config in the Code-First pair. Require a description in that section. Apply only the described compatible changes to existing dependency declarations. Requests for new dependencies or contract changes belong in a normal increment.
- section_boundaries: A Deploy module: line begins a section. Its description ends at the first blank line, next recognized directive or Lxx ID, or end of Notepad. Do not attach prose following a blank line to the preceding deployment. Multiple sections may be delivered together as one patch. Ask for clarification if the target is missing or a required description is empty.
- module_name: Deploy module: <name> with no description copies all existing C# implementation files for that module from the verified Code-First pair byte-for-byte, preserving relative paths under deployment_zero_patch/. Record identical baseline and replacement hashes for each file and keep explicit copy entries. This applies to every existing module, including CAM, SYS and EMPTY. With a description, use the normal implementation-only rule.

Return one ZIP named in the request. Put deployment_zero_patch/entry.json in its root alongside the whole replacements at deployment_zero_patch/<original device/... path>, keeping each relative path. Include schema_version 1.0, a revision, state UNVERIFIED, supported_pair_sha256, and one files entry per replacement with source relative to deployment_zero_patch/, target device/... path, baseline_sha256 from the exact original Code-First member and replacement_sha256. Preserve the original pair and Package 0. Do not generate Package 1, Package 2 or a new pair. No automatic application or verification; review and test in VS2022.

For this initial handoff, this branch overrides normal increment phase rules and output naming, including the downstream workflow's generation rules.

## Output naming and review corrections

New outputs use the Explorer-selected ModelCraft_ prefix; legacy ModelCraft_ inputs remain valid and immutable. Use the projection family, target version and output names from package0. Review corrections preserve the user-selected version and canonical filenames. A new target version requires a new user request. Record the prior and replacement SHA-256 and the correction reason. Retain the exact superseded archive at a content-addressed history path, preserving original review bytes; map the historical subject to its stored path. Bind the new OUT review to the replacement SHA-256. Only the candidate referenced by the active handoff may proceed.

## Module migration shortcuts

- `Integrate module: CAM -> MEDIA:EMPTY+CAM` — Move the existing source contract to the named destination resource; update affected composition, bindings, callers, subscriptions and tests. Remove the source from the new target composition; preserve the baseline.
- `Integrate module: CAM => MEDIA:EMPTY+CAM` — Copy the existing source contract to the named destination resource; retain the source in the target. Do not automatically activate a second instance of the same physical hardware.

## Step 2 result README

After Step 2, replace the pending placeholder in package2/README.md. For each result, report its exact archive path, state and verification scope from the final manifest. Distinguish inherited evidence from newly performed checks. Refresh the README after verification or any state change; validate that it agrees with the final manifest before handoff.

## Package 1 handoff identity

Model-First OUT and Code-First IN must validate the active Package 1 result against the projection and the nested device/entry.json. Use result.identity as the separate canonical package name and result.version as the separate version. Require nested Design.declaration.name and version to equal those values, and label to equal name@version. Check the ZIP path against the declared projection output and verify the exact SHA-256 against result.sha256. Report the field, expected value and actual value on mismatch. Stop the handoff or generation until the discrepancy is resolved.
