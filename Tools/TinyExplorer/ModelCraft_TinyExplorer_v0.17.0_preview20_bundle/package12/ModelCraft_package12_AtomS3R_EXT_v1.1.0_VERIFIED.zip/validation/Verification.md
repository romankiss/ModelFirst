# Static verification — ModelCraft_package12_AtomS3R_EXT 1.1.0

Baseline `ModelCraft_package12_XIAOSenseMAX@1.4.0` (VERIFIED) SHA-256 `ed72218a78dd441f3916f9e15658bc1c11c4e97ceb791c87dd487bb2a9526049`. ATOMS3R_EXT board HAL, buses spi1/i2c1/i2c2/uart1, MEDIA SD disabled with MEDIA DDR 1.6.0, connector board branch. Static integrity: PASS.

Final state: VERIFIED. See [runtime acceptance](RuntimeAcceptance.md).
