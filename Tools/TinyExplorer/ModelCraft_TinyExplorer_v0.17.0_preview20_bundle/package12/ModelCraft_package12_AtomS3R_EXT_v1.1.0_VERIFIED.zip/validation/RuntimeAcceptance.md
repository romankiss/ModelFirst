# Runtime acceptance — ModelCraft_package12_AtomS3R_EXT_v1.1.0

Owner device smoke test, 2026-11-24. Compiler and flasher OK. Startup banner confirmed Code-First 1.1.0. SYS LED opened on GPIO 18 LOW, FLASH opened, LoRa OPEN/SETUP succeeded, and application startup completed.

- MEDIA SD INFO returned opened=false and delivered MEDIA/SD/INFO to EMPTY0. SD OPEN returned ESD:disabled. UNSUB removed one subscription.
- LoRa SEND_ACK queued PING #3110 with context 00003110. EMPTY0 received LORA/QRX/PACK with ACK_PING #3110 from 5000 to 0808. RX context was zero. The payload token establishes correlation for this responder.
- SENSORS TH OPEN, READ and CLOSE passed. READ returned 26.17 °C and 25.87 % RH. READ after CLOSE returned ENOTOPEN.
- MEDIA CAM CAPTURE,LOG|EVENT returned Qvga JPEG, 3910 bytes. Capture and command result are covered. Event delivery was outside this smoke test.
