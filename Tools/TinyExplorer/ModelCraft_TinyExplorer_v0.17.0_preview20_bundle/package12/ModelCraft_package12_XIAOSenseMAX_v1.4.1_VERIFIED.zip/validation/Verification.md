# Static verification — ModelCraft_package12_XIAOSenseMAX 1.4.1

Parent `ModelCraft_package12_XIAOSenseMAX@1.4.0` (VERIFIED) SHA-256 `ed72218a78dd441f3916f9e15658bc1c11c4e97ceb791c87dd487bb2a9526049`. Bus kind parameter on bus resources (DDR 1.5.1, HAL, README); code unchanged. Static integrity: PASS. On device acceptance set Runtime.validation.state to VERIFIED in the pair manifest and Runtime.validation.target_runtime_state to VERIFIED in both package manifests, and record the RKB in validation/RuntimeAcceptance.md.

Final state: VERIFIED. See [runtime acceptance](RuntimeAcceptance.md).
