# Empty0 increment templates

For another instance, add an entry to `Runtime.composition.instances` and to `Deployment.metadata_bindings.empty.composition_instances` with a distinct suffix (for example `"1", ctx` for EMPTY1), then update `ordered_chain`, `head` and `tail`. Exercise original and new endpoints with distinct contexts.

For a new agile module, create a Module and AT DDR using the EMPTY structure. Give it its own identity, revise both DDRs together and declare its creation inputs and typed HAL contract (roles `physical_pin`, `pin_set`, `bus_parameter`) as in the XIAOSenseMAX reference pair. Bind every HAL parameter in `Deployment.metadata_bindings.<module>.resource_bindings`, project every HAL-derived constant inside the board preprocessor branch of `Program.cs`, and give the module README a HAL connector template: pin symbols first, a blank line, then HAL resources with descriptions. Keep the full shared `device/lib` tree in each package.
