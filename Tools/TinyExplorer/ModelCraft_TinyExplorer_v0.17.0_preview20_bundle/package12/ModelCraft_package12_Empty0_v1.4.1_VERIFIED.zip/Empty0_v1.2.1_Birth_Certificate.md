# Empty0 v1.2.1

This manually assembled ModelCraft baseline contains one EMPTY0 instance above VirtualModule. Package 1 owns the Level 0 and EMPTY DDR contracts. Package 2 owns the nanoFramework projection. Both members carry the same complete shared library tree.

The EMPTY semantic contract revision is 1.1.0 in both DDRs. The pair and member version is 1.2.1. The canonical fingerprint covers the current contract identity and paths.

Status VERIFIED for naming and provenance migration, with inherited device assurance. See validation/Verification.md for scope. The regression scenario is in the Code-First member.
