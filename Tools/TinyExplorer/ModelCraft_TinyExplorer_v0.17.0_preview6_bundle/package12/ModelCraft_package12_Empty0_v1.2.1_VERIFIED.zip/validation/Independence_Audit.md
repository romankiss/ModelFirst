# Empty0 v1.2.1 independence audit

Static review checked member identities and versions, archive integrity, artifact and member digests, source Package 1 digest, DDR reference resolution, EMPTY fingerprint, one EMPTY0 instance and the shared library tree.

The release contains only current model and target members, the current birth certificate, increment hints and this static audit. Device assurance is inherited. The external baseline import was not executed.
