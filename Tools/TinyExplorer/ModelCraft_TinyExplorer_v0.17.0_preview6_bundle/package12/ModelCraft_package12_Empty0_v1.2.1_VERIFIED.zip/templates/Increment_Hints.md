# Empty0 increment templates

For another instance, add an entry to Runtime.composition.instances with the existing module_ref, a distinct suffix and endpoint, then update topology.order, head and tail as required. Exercise original and new endpoints with distinct contexts.

For a new agile module, create a module and AT DDR using the EMPTY structure. Give it its own identity, revise both DDRs together and declare Create inputs through the Metadata Connector, including defaults for optional inputs where appropriate. Map the partial class in the platform projection. Keep the full shared device/lib tree in each package.
