# XIAOSenseMAX v1.0.0 runtime acceptance

Date: 2026-11-21. Board: XIAO_ESP32S3_SENSE. Scope: rename increment of the verified XIAOSense v1.3.4 baseline. The pair preserves both submitted ZIPs byte for byte. This acceptance applies to the pair.

| Check | Result and evidence |
|---|---|
| Build and flash | PASS, operator reported compiler=ok and flasher=ok. |
| Startup identity | PASS, 12:58:01.079 [Platform] === ModelCraft_package2_XIAOSenseMAX 1.0.0 === |
| Composition | PASS, workers started in order SYS, EMPTY0, EMPTY1, MEDIA, SENSORS, LORA. |
| Activation | PASS, FLASH OPEN, LORA OPEN and LORA SETUP returned +OK. NEO, LED and BUTTON were skipped as unassigned. |
| Readiness | PASS, 12:58:11.626 Modules are READY and 12:58:11.631 ApplicationStartUp Done. |
| SEND_ACK | PASS, PUSH subscription registered for LORA on /QRX/PACK with filter ACK_PING*. PING #1234 was queued and transmitted with ctx 00000911. At 13:00:24.265 the LORA consumer handled ACK_PING #1234 from 0x5000 to 0x0888 with ctx 00000000. Correlation is by payload #1234. |

The /INIT/READY routing and delivery check applies when a subscription exists before emission. With no consumer, the runtime neither routes nor logs the event. Readiness for this increment is evidenced by the startup traces and successful SEND_ACK.

Static review confirmed the Package 2 reference to the exact Package 1 SHA-256 and the absence of embedded DDR files in Package 2. Compared with baseline Package 2, the only executable-source delta is the startup banner literal in Program.cs. Full peripheral regression is inherited within the baseline evidence scope.
