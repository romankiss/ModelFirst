# Empty0 increment templates

For another instance, add an entry to `Runtime.composition.instances` and to `Deployment.metadata_bindings.empty.composition_instances` with a distinct suffix (for example `"1", ctx` for EMPTY1), then update `ordered_chain`, `head` and `tail`. Exercise original and new endpoints with distinct contexts.

For a new agile module, create a Module and AT DDR using the EMPTY structure. Give it its own identity, revise both DDRs together and declare its creation inputs and typed HAL contract (roles `physical_pin`, `pin_set`, `bus_parameter`) as in the XIAOSenseMAX reference pair. Bind every HAL parameter in `Deployment.metadata_bindings.<module>.resource_bindings` (a module without resources declares one contract in `Design.hal`, binds it in `Deployment.metadata_bindings.<module>.module_bindings`, keeps its values in `HAL.modules.<module>` and is listed in a bus's `devices` with `module` only), project every HAL-derived constant inside the board preprocessor branch of `Program.cs`, and give the module README a HAL connector template: pin symbols first, a blank line, then HAL resources with descriptions. Keep the full shared `device/lib` tree in each package.

When a derived target attaches a device to one of the template buses, remove `reserved` from that bus; `reserved true` is only for a bus without devices.
