# Static verification — ModelCraft_package12_Empty0 1.4.2

Parent `ModelCraft_package12_Empty0@1.4.1` (VERIFIED, preview 20) SHA-256 `ecf9c9f7f5ab8d43339605917d9788d905fd8f0d068b197dcc7a5af33c71f546`.

- B5: buses spi1, i2c1, uart0 declare reserved true (lines intentionally reserved without devices; no 'bus mapped without devices' warning); rule text: reserved true with an enabled device is rejected.
- Common rule wording: bus user = module resource or module without resources (devices, assignment, enabled, disabled projection, Notepad bus lines); reserved buses. No code change.

All C#, packages.config and device/lib byte-identical to 1.4.1; startup banner unchanged. Static integrity: PASS.

Final state: VERIFIED. See [runtime acceptance](RuntimeAcceptance.md).
