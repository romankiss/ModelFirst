# Runtime acceptance — ModelCraft_package12_XIAOSenseMAX_v1.4.1

Runtime acceptance inherited from `ModelCraft_package12_XIAOSenseMAX@1.4.0`. C#, build configuration and device/lib byte-identical; only DDR, HAL value bus (not projected into code) and README changed. See [RuntimeAcceptance_1.4.0.md](RuntimeAcceptance_1.4.0.md).
