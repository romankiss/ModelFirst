# Runtime acceptance — ModelCraft_package12_XIAOSenseMAX_v1.4.2

Owner accepted inherited runtime evidence from `ModelCraft_package12_XIAOSenseMAX@1.4.1` (SHA-256 `04e6873653ffd38191b663991bb176f03f855ac322c3f59daecac019b49215f3`). C#, build configuration and runtime library files were compared byte for byte. No new runtime tests were performed. See [RuntimeAcceptance_1.4.1.md](RuntimeAcceptance_1.4.1.md).
