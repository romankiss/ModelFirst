# XIAOSenseMAX v1.4.0 runtime acceptance

The scoped XIAOSenseMAX runtime acceptance is inherited from the verified v1.3.1 pair.
Parent SHA-256: `3d54badcf7056dd8a8ad98656ddc70225016b76732a1b415293f555dc605f3d4`.

All executable and build inputs match v1.3.1
byte-for-byte in each projection. The runtime banner remains 1.3.1.
The v1.4.0 HAL metadata preserves the target configuration and composition. No new compile, flash or hardware execution was performed.
The new HAL authoring rules were reviewed statically. Generation for a derived board and resource deactivation are outside this runtime evidence.

See [original runtime acceptance](RuntimeAcceptance_1.3.1.md) for the
operator evidence and scoped regression results.
