# Static verification — ModelCraft_package12_XIAOSenseMAX 1.4.2

Parent `ModelCraft_package12_XIAOSenseMAX@1.4.1` (VERIFIED, preview 20) SHA-256 `04e6873653ffd38191b663991bb176f03f855ac322c3f59daecac019b49215f3`.

- B1: LORA is a module without resources (Module and AT DDR 1.6.0, fingerprint recomputed): RADIO + MODEM merged into Design.hal with groups device (OPEN) and modem (SETUP), one module-level enabled; HAL.modules.lora.<param>; bus devices entry with module only; module_bindings; constant_projection sources; README rewritten.
- Common rule wording: bus user = module resource or module without resources (devices, assignment, enabled, disabled projection, Notepad bus lines); reserved buses. No code change.

All C#, packages.config and device/lib byte-identical to 1.4.1; startup banner unchanged. Static integrity: PASS.

Final state: VERIFIED. See [runtime acceptance](RuntimeAcceptance.md).
