# Static verification — ModelCraft_package12_AtomS3R_EXT 1.1.1

Parent `ModelCraft_package12_AtomS3R_EXT@1.1.0` (VERIFIED, preview 20) SHA-256 `eaa03c5ade2acfba49435f3119b029a7202cd567da5b8a5731be711e4cece695`.

- B1: LORA is a module without resources (Module and AT DDR 1.6.0, fingerprint recomputed): RADIO + MODEM merged into Design.hal with groups device (OPEN) and modem (SETUP), one module-level enabled; HAL.modules.lora.<param>; bus devices entry with module only; module_bindings; constant_projection sources; README rewritten.
- B5: buses i2c1 declare reserved true (lines intentionally reserved without devices; no 'bus mapped without devices' warning); rule text: reserved true with an enabled device is rejected.
- B3: Runtime.composition sensors arguments_expression aligned with Deployment.metadata_bindings.sensors.factory (thI2cBusId); code was already correct.
- Common rule wording: bus user = module resource or module without resources (devices, assignment, enabled, disabled projection, Notepad bus lines); reserved buses. No code change.

All C#, packages.config and device/lib byte-identical to 1.1.0; startup banner unchanged. Static integrity: PASS.

Final state: VERIFIED. See [runtime acceptance](RuntimeAcceptance.md).
