# ModelCraft XIAOSenseMAX v1.1.8 — VERIFIED

Documentation-only revision of `ModelCraft_package12_XIAOSenseMAX_v1.1.7_VERIFIED.zip`.

- Module README DDR tables list pin symbols first and HAL properties second, separated by a blank line when both groups exist. Removed only descriptions of bare pin symbols. HAL descriptions and values are preserved.
- Runtime acceptance is inherited from v1.1.7. All files other than manifests and Markdown documentation are byte-identical in both projections. No new compile, flash or hardware test was performed.
- The firmware startup banner continues to report `ModelCraft_package2_XIAOSenseMAX 1.1.7`. The pair and member manifests identify package revision 1.1.8.
- Parent pair SHA-256: `678a2c4dd565b1abb262e58a20e250a9d8ffb980d0711061204c453bf8600d75`.

## Inherited evidence from v1.1.7

# ModelCraft XIAOSenseMAX 1.1.7 — VERIFIED

Static integrity passed, including the EMPTY HAL contract and matching README and manifests.

## Target runtime acceptance — PASS

Operator evidence from compiler, flasher and AppLog on XIAO ESP32S3 Sense.

- Compile and flash: operator reported OK.
- 22:41:28.989: banner identified Code-First MAX 1.1.7. SYS, EMPTY0, EMPTY1, MEDIA, SENSORS and LORA workers started. SYS FLASH OPEN, LORA OPEN and LORA SETUP returned +OK. Modules reached READY and ApplicationStartUp completed.
- At startup NEO, LED and BUTTON were unassigned and activation was skipped. The readiness evidence is the platform log. Delivery of /INIT/READY requires a subscriber registered before emission.
- First SEND_ACK (PING #1234): PUSH subscription created before TX. RX traffic reached EMPTY0, and this attempt yielded no captured correlated ACK.
- Second SEND_ACK (PING #911): reused the existing EMPTY0 PUSH subscription. QueueTX at 22:46:46.282 used ctx=00000911. QueueRX at 22:46:52.638 received from 0x5557 to 0x0888 with the same context. LORA emitted /QRX/PACK, then EMPTY0 received and handled ACK_PING #911 at 22:46:52.686 with ctx=00000911.
- The filter also delivered the unrelated broadcast Hello, #206 with ctx=550000CE. ACK acceptance used the matching context and payload.
- Coverage is limited to the checks recorded here. MEDIA and SENSORS worker startup was observed.
